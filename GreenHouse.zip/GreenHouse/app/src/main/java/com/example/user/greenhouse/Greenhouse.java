package com.example.user.greenhouse;

class Greenhouse {
//    @SerializedName("product_name")
    //shop_id,shop_name,shop_cat,city,area,address,work_details,price_details
    private String temp;
    private String humidity;
    private String soil;




    public Greenhouse(String temp, String humidity, String soil) {

        this.temp = temp;
        this.humidity = humidity;
        this.soil = soil;



    }
    public String gettemp() {
        return temp;
    }
    public String gethumidity() {
        return humidity;
    }
    public String getsoil() {
        return soil;
    }




}
