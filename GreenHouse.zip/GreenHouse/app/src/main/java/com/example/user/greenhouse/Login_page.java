package com.example.user.greenhouse;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login_page extends AppCompatActivity {

    EditText editText_mno, editText_password;
    Button button_login, button_create;
    String s1, s2;
    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

    ProgressDialog progressBar;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);



        editText_mno = (EditText) findViewById(R.id.et_login_mno_user);
        editText_password = (EditText) findViewById(R.id.et_login_password_user);
        button_login = (Button) findViewById(R.id.btn_login_user);









        button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String username = editText_mno.getText().toString();
                String password = editText_password.getText().toString();


                          //validate form
                if(username.equals("admin") && password.equals("123456"))
                {



                    //do login
                  //  doLogin(username, password);
                    Intent intent=new Intent(getApplication(),MainActivity.class);
                    startActivity(intent);
                    finish();
                    Toast.makeText(Login_page.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(Login_page.this, "Login Fail", Toast.LENGTH_SHORT).show();
                }


            }
        });







    }



//    private void chk_log() {
//        try {
//            StrictMode.setThreadPolicy(policy);
//            InputStream is = null;
//
//            s1 = editText_mno.getText().toString();
//            s2 = editText_password.getText().toString();
//
//            sharedPrefHandler.setSharedPreferences("mno", s1);
//
//            String result = null;
//
//            ArrayList<NameValuePair> nvp = new ArrayList<NameValuePair>();
//
//            nvp.add(new BasicNameValuePair("f1", s1));
//            nvp.add(new BasicNameValuePair("f2", s2));
//
//            //Toast.makeText(getApplication(), v1, Toast.LENGTH_LONG).show();
//            HttpClient hclient = new DefaultHttpClient();
//            HttpPost hpost = new HttpPost("https://broken-winded-slash.000webhostapp.com/QR_CODE/login.php");
//            hpost.setEntity(new UrlEncodedFormEntity(nvp));
//            HttpResponse resp = hclient.execute(hpost);
//            HttpEntity hent = resp.getEntity();
//            is = hent.getContent();
//
//
//            BufferedReader rd = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
//            StringBuilder sb = new StringBuilder();
//            String ln = null;
//            while ((ln = rd.readLine()) != null) {
//                sb.append(ln);
//            }
//            is.close();
//            result = sb.toString().trim();
//            Log.d("respo", result);
//
//
//            //JSONObject object = new JSONObject(result);
//            //  String ch=object.getString("r");
//            //  Toast.makeText(getApplication(), ch, Toast.LENGTH_LONG).show();
//            result = result.substring(1, result.length() - 1);
//            //Toast.makeText(getApplication(), result, Toast.LENGTH_LONG).show();
//            if (!result.trim().equals("Error")) {
//                String[] r = result.split("-");
//                //usn=r[0].toString();
//                //std_name=r[1].toString().toUpperCase();
//
//                Toast.makeText(this, "Login Successfull", Toast.LENGTH_SHORT).show();
//
//                //sharedPrefHandler.setSharedPreferences("email",usn);
//                Intent in = new Intent(getApplication(), MainActivity.class);
//                startActivity(in);
//            } else
//                Toast.makeText(getApplication(), "Invalid Username /Password", Toast.LENGTH_LONG).show();
//        } catch (Exception ex) {
//            Toast.makeText(getApplication(), ex.getMessage(), Toast.LENGTH_LONG).show();
//        }
//    }


}