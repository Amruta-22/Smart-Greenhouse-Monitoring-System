package com.example.user.greenhouse;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity
{

    TextView cardView_one,cardView_two,cardView_three,cardView_four;

    String string_product;
    Button button;
    List<Greenhouse> productList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        cardView_one=(TextView)findViewById(R.id.btn_temp);
        cardView_two=(TextView)findViewById(R.id.btn_hb);
        cardView_three=(TextView)findViewById(R.id.btn_oxigen);
        button=(Button)findViewById(R.id.btn_refresh);





        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent=new Intent(getApplication(),MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        getlatitude();



    }


    private void getlatitude() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        Api api = retrofit.create(Api.class);

        Call<List<Greenhouse>> call = api.Health( );

        call.enqueue(new Callback<List<Greenhouse>>() {
            @Override
            public void onResponse(Call<List<Greenhouse>> call, Response<List<Greenhouse>> response) {
                productList = response.body();

                Boolean isSuccess = false;
                if (response.body() != null) {
                    isSuccess = true;
                }

                if (isSuccess) {
                    cardView_one.setText("Tempreture : " + productList.get(0).gettemp());
                    cardView_two.setText("Humidity : " + productList.get(0).gethumidity());
                    cardView_three.setText("Soil : " + productList.get(0).getsoil());


                    //finish();

                } else {

                }
            }

            @Override
            public void onFailure(Call<List<Greenhouse>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
