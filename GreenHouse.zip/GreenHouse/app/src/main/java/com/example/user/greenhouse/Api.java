package com.example.user.greenhouse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Api {
    // String BASE_URL = "https://simplifiedcoding.net/demos/";
    // String BASE_URL = "https://fanciful-petroleum.000webhostapp.com/api/";
    String BASE_URL = "https://wizard-focuses.000webhostapp.com/greenhouse/";



    @GET("https://wizard-focuses.000webhostapp.com/greenhouse/fetch_parameter.php")
    Call<List<Greenhouse>> Health();



}
